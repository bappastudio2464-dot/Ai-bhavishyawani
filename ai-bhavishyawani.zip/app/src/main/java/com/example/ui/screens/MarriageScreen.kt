package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CelestialEmerald
import com.example.ui.theme.CosmicPurpleSecondary
import com.example.ui.theme.MysticGoldPrimary
import com.example.ui.viewmodel.AstrologyViewModel

data class MarriageBiodata(
    val fullName: String = "",
    val age: Int = 26,
    val gender: String = "Male",
    val height: String = "5 ft 10 in",
    val education: String = "B.Tech / MCA",
    val profession: String = "Senior Software Engineer",
    val income: String = "₹12 - 15 Lakhs/year",
    val religionCaste: String = "Hindu / Brahmin",
    val gotra: String = "Kashyap",
    val manglikStatus: String = "Non-Manglik",
    val familyCity: String = "New Delhi",
    val contactPhone: String = "+91 9876543210",
    val bio: String = "Looking for a caring, educated and family-oriented life partner.",
    val avatarEmoji: String = "👨‍💼"
)

data class CommunityProfile(
    val id: Int,
    val name: String,
    val age: Int,
    val gender: String,
    val height: String,
    val education: String,
    val profession: String,
    val income: String,
    val gotra: String,
    val city: String,
    val manglik: String,
    val bio: String,
    val avatarEmoji: String,
    var isFollowed: Boolean = false,
    var followersCount: Int = 120,
    var isBlocked: Boolean = false
)

data class DirectChatMessage(
    val sender: String, // "ME" or "OTHER"
    val text: String,
    val time: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarriageScreen(viewModel: AstrologyViewModel) {
    val profile by viewModel.userProfile.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Vivah Prediction, 1: Mera Vivah Resume, 2: Community & Chat

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Tab Bar
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MysticGoldPrimary,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("🔮 Shadi Yog", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("📝 Mera Biodata", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("👫 Rishtey & Chat", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
            )
        }

        when (selectedTab) {
            0 -> VivahPredictionTab(viewModel)
            1 -> MeraMarriageBiodataTab(userProfileName = profile?.name ?: "")
            2 -> CommunityRishteyTab()
        }
    }
}

@Composable
private fun VivahPredictionTab(viewModel: AstrologyViewModel) {
    val prediction = viewModel.getMarriagePrediction()
    val profile by viewModel.userProfile.collectAsState()

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            // Marriage Header Banner
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    CosmicPurpleSecondary.copy(alpha = 0.4f),
                                    MaterialTheme.colorScheme.surfaceVariant
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            shape = CircleShape,
                            color = MysticGoldPrimary.copy(alpha = 0.2f),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = "Vivah Yog",
                                    tint = MysticGoldPrimary,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Shadi Kab Hogi? Vivah Yog 2026-2027",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MysticGoldPrimary,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "Vedic Astrological Marriage Prediction for ${profile?.name?.ifBlank { "You" }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        item {
            // Estimated Age & Year Cards
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MysticGoldPrimary.copy(alpha = 0.5f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Probable Marriage Age",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = prediction.estimatedMarriageAge,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MysticGoldPrimary,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CelestialEmerald.copy(alpha = 0.5f)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Strongest Year Window",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = prediction.probableYearRange,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = CelestialEmerald,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        item {
            // Partner Characteristics & Direction
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "1. Jeevan Sathi (Life Partner) Characteristics",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = prediction.lifePartnerCharacteristics,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "2. Partner Direction & Meeting Sthan",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = prediction.partnerDirection,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        item {
            // Powerful Marriage Remedies (Upay)
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Siddha Vivah Upay & Remedies for Early Marriage",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    prediction.powerfulMarriageRemedies.forEachIndexed { index, remedy ->
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = "${index + 1}. ",
                                fontWeight = FontWeight.Bold,
                                color = MysticGoldPrimary,
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = remedy,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MeraMarriageBiodataTab(userProfileName: String) {
    val context = LocalContext.current

    var nameText by remember { mutableStateOf(userProfileName.ifBlank { "User Name" }) }
    var ageText by remember { mutableStateOf("26") }
    var heightText by remember { mutableStateOf("5 ft 10 in") }
    var eduText by remember { mutableStateOf("B.Tech / MBA") }
    var profText by remember { mutableStateOf("Senior Software Engineer") }
    var incomeText by remember { mutableStateOf("₹12 - 15 LPA") }
    var gotraText by remember { mutableStateOf("Kashyap") }
    var manglikText by remember { mutableStateOf("Non-Manglik") }
    var cityText by remember { mutableStateOf("New Delhi") }
    var phoneText by remember { mutableStateOf("+91 9876543210") }
    var bioText by remember { mutableStateOf("Family-oriented, cultured, well-educated and looking for a compatible partner.") }
    var avatarText by remember { mutableStateOf("👨‍💼") }

    val avatars = listOf("👨‍💼", "👩‍💼", "🤴", "👸", "👨‍💻", "👩‍💻", "👨‍⚕️", "👩‍⚕️")

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "📝 Fill Your Marriage Biodata (शादी के लिए बायोडाटा)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )
                    Text(
                        text = "Ye details bharne par dusre users aapka profile rishte ke liye dekh aur follow kar sakenge.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(text = "Choose Profile Avatar / Photo Icon:", style = MaterialTheme.typography.labelMedium, color = MysticGoldPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(avatars) { av ->
                            Surface(
                                shape = CircleShape,
                                color = if (avatarText == av) MysticGoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clickable { avatarText = av }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = av, fontSize = 24.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = nameText,
                        onValueChange = { nameText = it },
                        label = { Text("Pura Naam (Full Name)") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        OutlinedTextField(
                            value = ageText,
                            onValueChange = { ageText = it },
                            label = { Text("Umar (Age)") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = heightText,
                            onValueChange = { heightText = it },
                            label = { Text("Height (5'10\")") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = eduText,
                        onValueChange = { eduText = it },
                        label = { Text("Shiksha (Education Degree)") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    )

                    OutlinedTextField(
                        value = profText,
                        onValueChange = { profText = it },
                        label = { Text("Kaam / Profession / Job") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        OutlinedTextField(
                            value = incomeText,
                            onValueChange = { incomeText = it },
                            label = { Text("Varshik Aay (Annual Package)") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = gotraText,
                            onValueChange = { gotraText = it },
                            label = { Text("Gotra / Caste") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        OutlinedTextField(
                            value = manglikText,
                            onValueChange = { manglikText = it },
                            label = { Text("Manglik Status") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = cityText,
                            onValueChange = { cityText = it },
                            label = { Text("City / Sthan") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = phoneText,
                        onValueChange = { phoneText = it },
                        label = { Text("Contact Number / WhatsApp") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    )

                    OutlinedTextField(
                        value = bioText,
                        onValueChange = { bioText = it },
                        label = { Text("Bio / Partner Expectation (Apeksha)") },
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            Toast.makeText(context, "Mera Marriage Biodata Safaltapoorvak Save Ho Gaya!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MysticGoldPrimary),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Save, contentDescription = "Save", tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save Vivah Resume / Biodata", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CommunityRishteyTab() {
    val context = LocalContext.current

    val candidateProfiles = remember {
        mutableStateListOf(
            CommunityProfile(
                id = 1,
                name = "Priya Sharma",
                age = 24,
                gender = "Female",
                height = "5 ft 5 in",
                education = "M.Tech in CS",
                profession = "Software Engineer at MNC",
                income = "₹14 LPA",
                gotra = "Vashishtha",
                city = "New Delhi",
                manglik = "Non-Manglik",
                bio = "Family oriented, loves classical music & reading. Looking for an educated groom.",
                avatarEmoji = "👩‍💼",
                followersCount = 340
            ),
            CommunityProfile(
                id = 2,
                name = "Rahul Verma",
                age = 27,
                gender = "Male",
                height = "5 ft 11 in",
                education = "MBA Finance",
                profession = "Assistant Vice President",
                income = "₹22 LPA",
                gotra = "Kashyap",
                city = "Mumbai",
                manglik = "Anshik Manglik",
                bio = "Focused on career & family values. Looking for a smart, caring partner.",
                avatarEmoji = "👨‍💼",
                followersCount = 512
            ),
            CommunityProfile(
                id = 3,
                name = "Ananya Sen",
                age = 25,
                gender = "Female",
                height = "5 ft 4 in",
                education = "MBBS Doctor",
                profession = "Resident Medical Officer",
                income = "₹18 LPA",
                gotra = "Bharadwaj",
                city = "Kolkata",
                manglik = "Non-Manglik",
                bio = "Doctor by profession, passionate about yoga & cultural events.",
                avatarEmoji = "👩‍⚕️",
                followersCount = 420
            ),
            CommunityProfile(
                id = 4,
                name = "Vikas Pandey",
                age = 28,
                gender = "Male",
                height = "6 ft 0 in",
                education = "B.E. Mechanical",
                profession = "Government Civil Engineer",
                income = "₹15 LPA",
                gotra = "Garg",
                city = "Lucknow",
                manglik = "Non-Manglik",
                bio = "Simple living, high thinking. Looking for a cultured life partner.",
                avatarEmoji = "👨‍💻",
                followersCount = 289
            ),
            CommunityProfile(
                id = 5,
                name = "Sneha Gupta",
                age = 26,
                gender = "Female",
                height = "5 ft 3 in",
                education = "CA (Chartered Accountant)",
                profession = "Senior Financial Analyst",
                income = "₹16 LPA",
                gotra = "Agrawal",
                city = "Jaipur",
                manglik = "Manglik",
                bio = "Religious, cheerful and creative. Looking for a family-loving partner.",
                avatarEmoji = "👸",
                followersCount = 390
            ),
            CommunityProfile(
                id = 6,
                name = "Aditya Joshi",
                age = 29,
                gender = "Male",
                height = "5 ft 10 in",
                education = "MS Data Science",
                profession = "AI Research Scientist",
                income = "₹28 LPA",
                gotra = "Shandilya",
                city = "Bengaluru",
                manglik = "Non-Manglik",
                bio = "Tech enthusiast, hiker and avid reader seeking a well-educated partner.",
                avatarEmoji = "🤴",
                followersCount = 610
            )
        )
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedGenderFilter by remember { mutableStateOf("All") }
    var selectedManglikFilter by remember { mutableStateOf("All") }
    var selectedCityFilter by remember { mutableStateOf("All") }

    var activeChatProfile by remember { mutableStateOf<CommunityProfile?>(null) }
    var chatMessageInput by remember { mutableStateOf("") }
    val chatMessagesMap = remember { mutableStateMapOf<Int, MutableList<DirectChatMessage>>() }

    // Filter Logic
    val filteredProfiles = candidateProfiles.filter { candidate ->
        val queryLower = searchQuery.trim().lowercase()
        val matchesQuery = queryLower.isEmpty() ||
                candidate.name.lowercase().contains(queryLower) ||
                candidate.gotra.lowercase().contains(queryLower) ||
                candidate.city.lowercase().contains(queryLower) ||
                candidate.profession.lowercase().contains(queryLower) ||
                candidate.manglik.lowercase().contains(queryLower)

        val matchesGender = when (selectedGenderFilter) {
            "Male" -> candidate.gender.equals("Male", ignoreCase = true)
            "Female" -> candidate.gender.equals("Female", ignoreCase = true)
            else -> true
        }

        val matchesManglik = when (selectedManglikFilter) {
            "Non-Manglik" -> candidate.manglik.contains("Non", ignoreCase = true)
            "Manglik" -> !candidate.manglik.contains("Non", ignoreCase = true)
            else -> true
        }

        val matchesCity = when (selectedCityFilter) {
            "All" -> true
            else -> candidate.city.equals(selectedCityFilter, ignoreCase = true)
        }

        matchesQuery && matchesGender && matchesManglik && matchesCity
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "👫 Vivah Rishtey & Marriage Profiles Community",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MysticGoldPrimary
            )
            Text(
                text = "Profiles dekhein, Naam, Caste, Location & Status se Search karein, Follow aur Direct Chat karein.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.8f)
            )
        }

        // Search & Filter Box Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MysticGoldPrimary.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Search Text Box
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search by Name, Caste/Gotra, City, Profession...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = MysticGoldPrimary) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = MaterialTheme.colorScheme.outline)
                                }
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Filter Chips Row 1: Gender
                    Text("Gender Filter:", style = MaterialTheme.typography.labelSmall, color = MysticGoldPrimary, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                    ) {
                        listOf("All", "Female", "Male").forEach { genderOption ->
                            FilterChip(
                                selected = selectedGenderFilter == genderOption,
                                onClick = { selectedGenderFilter = genderOption },
                                label = { Text(genderOption, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MysticGoldPrimary,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    // Filter Chips Row 2: Manglik Status
                    Text("Manglik Status Filter:", style = MaterialTheme.typography.labelSmall, color = MysticGoldPrimary, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                    ) {
                        listOf("All", "Non-Manglik", "Manglik").forEach { manglikOption ->
                            FilterChip(
                                selected = selectedManglikFilter == manglikOption,
                                onClick = { selectedManglikFilter = manglikOption },
                                label = { Text(manglikOption, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CelestialEmerald,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    // Filter Chips Row 3: Major Cities
                    Text("Location / City Filter:", style = MaterialTheme.typography.labelSmall, color = MysticGoldPrimary, fontWeight = FontWeight.Bold)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        items(listOf("All", "New Delhi", "Mumbai", "Kolkata", "Lucknow", "Jaipur", "Bengaluru")) { cityOption ->
                            FilterChip(
                                selected = selectedCityFilter == cityOption,
                                onClick = { selectedCityFilter = cityOption },
                                label = { Text(cityOption, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    if (searchQuery.isNotEmpty() || selectedGenderFilter != "All" || selectedManglikFilter != "All" || selectedCityFilter != "All") {
                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(
                            onClick = {
                                searchQuery = ""
                                selectedGenderFilter = "All"
                                selectedManglikFilter = "All"
                                selectedCityFilter = "All"
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reset", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset All Filters", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }

        if (filteredProfiles.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier.padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SearchOff, contentDescription = "Not Found", tint = MysticGoldPrimary, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Koi matching Rishta Profile nahi mili.",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Kripya search term (Name, Gotra, City) badlein ya filter reset karein.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        items(filteredProfiles) { candidate ->
            if (candidate.isBlocked) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "🚫 Blocked Profile: ${candidate.name}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                        TextButton(
                            onClick = {
                                candidate.isBlocked = false
                                Toast.makeText(context, "${candidate.name} is Unblocked!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Text("Unblock", color = MysticGoldPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = MysticGoldPrimary.copy(alpha = 0.2f),
                                modifier = Modifier.size(56.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = candidate.avatarEmoji, fontSize = 28.sp)
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${candidate.name}, ${candidate.age} yrs",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "${candidate.profession} • ${candidate.city}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MysticGoldPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "Height: ${candidate.height} | Gotra: ${candidate.gotra} | ${candidate.manglik}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = candidate.bio,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Follow Button
                            Button(
                                onClick = {
                                    candidate.isFollowed = !candidate.isFollowed
                                    if (candidate.isFollowed) candidate.followersCount++ else candidate.followersCount--
                                    val msg = if (candidate.isFollowed) "Aapne ${candidate.name} ko Follow kar liya!" else "Unfollowed ${candidate.name}"
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (candidate.isFollowed) CelestialEmerald else MysticGoldPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (candidate.isFollowed) Icons.Default.Check else Icons.Default.PersonAdd,
                                        contentDescription = "Follow",
                                        tint = Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (candidate.isFollowed) "Following (${candidate.followersCount})" else "Follow (${candidate.followersCount})",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            // 1-on-1 Chat Button
                            Button(
                                onClick = {
                                    activeChatProfile = candidate
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Chat, contentDescription = "Chat", tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Chat (बात करें)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }

                            // Block Button
                            IconButton(
                                onClick = {
                                    candidate.isBlocked = true
                                    Toast.makeText(context, "${candidate.name} को Block कर दिया गया है।", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.Block, contentDescription = "Block User", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    // 1-on-1 Direct Chat Modal BottomSheet/Dialog
    activeChatProfile?.let { activeUser ->
        val userMessages = chatMessagesMap.getOrPut(activeUser.id) {
            mutableStateListOf(
                DirectChatMessage("OTHER", "Namaste! Aapka Marriage Biodata dekha, baat karein?", "10:15 AM")
            )
        }

        AlertDialog(
            onDismissRequest = { activeChatProfile = null },
            icon = {
                Text(text = activeUser.avatarEmoji, fontSize = 32.sp)
            },
            title = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Chat with ${activeUser.name}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${activeUser.profession} • ${activeUser.city}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MysticGoldPrimary
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(userMessages) { msg ->
                            val isMe = msg.sender == "ME"
                            Row(
                                horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isMe) MysticGoldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.widthIn(max = 220.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = msg.text,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (isMe) Color.Black else Color.White
                                        )
                                        Text(
                                            text = msg.time,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 9.sp,
                                            color = if (isMe) Color.Black.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.6f),
                                            textAlign = TextAlign.End,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = chatMessageInput,
                            onValueChange = { chatMessageInput = it },
                            placeholder = { Text("Message likhein...") },
                            shape = RoundedCornerShape(16.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (chatMessageInput.isNotBlank()) {
                                    val nowStr = "Just now"
                                    userMessages.add(DirectChatMessage("ME", chatMessageInput.trim(), nowStr))
                                    chatMessageInput = ""

                                    // Simulated response from candidate
                                    userMessages.add(
                                        DirectChatMessage("OTHER", "Dhanyawad message ke liye! Kundali & Gun Milan check karte hain.", nowStr)
                                    )
                                }
                            }
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = MysticGoldPrimary)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { activeChatProfile = null }) {
                    Text("Close", color = MysticGoldPrimary)
                }
            }
        )
    }
}
