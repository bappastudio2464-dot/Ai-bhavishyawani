package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.*
import com.example.data.repository.AstrologyRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class ScreenRoute {
    object Onboarding : ScreenRoute()
    object Home : ScreenRoute()
    object Mantra : ScreenRoute()
    object Kundali : ScreenRoute()
    object MarriagePrediction : ScreenRoute()
    object AiChat : ScreenRoute()
    object Remedies : ScreenRoute()
    object Profile : ScreenRoute()
}

class AstrologyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AstrologyRepository(AppDatabase.getDatabase(application))

    val userProfile: StateFlow<UserProfile?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val chatMessages: StateFlow<List<ChatMessage>> = repository.chatMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transitAlerts: StateFlow<List<TransitAlert>> = repository.transitAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentRoute = MutableStateFlow<ScreenRoute>(ScreenRoute.Home)
    val currentRoute: StateFlow<ScreenRoute> = _currentRoute.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(Language.HINDI)
    val selectedLanguage: StateFlow<Language> = _selectedLanguage.asStateFlow()

    private val _selectedMood = MutableStateFlow("Happy")
    val selectedMood: StateFlow<String> = _selectedMood.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultDataIfNeeded()
            userProfile.collect { profile ->
                if (profile != null) {
                    if (!profile.isOnboarded && _currentRoute.value !is ScreenRoute.Onboarding) {
                        _currentRoute.value = ScreenRoute.Onboarding
                    }
                    val matchedLang = Language.entries.find { it.name == profile.selectedLanguage }
                    if (matchedLang != null) {
                        _selectedLanguage.value = matchedLang
                    }
                } else {
                    _currentRoute.value = ScreenRoute.Onboarding
                }
            }
        }
    }

    fun navigateTo(route: ScreenRoute) {
        _currentRoute.value = route
    }

    fun setMood(mood: String) {
        _selectedMood.value = mood
    }

    fun setLanguage(language: Language) {
        _selectedLanguage.value = language
        viewModelScope.launch {
            repository.updateLanguage(language.name)
            _toastMessage.emit("Bhasha badli gayi: ${language.nativeName}")
        }
    }

    fun saveProfile(
        name: String,
        day: Int,
        month: Int,
        year: Int,
        hour: Int,
        minute: Int,
        amPm: String,
        city: String,
        gender: String
    ) {
        viewModelScope.launch {
            val existing = userProfile.value ?: UserProfile()
            val updated = existing.copy(
                name = name,
                dobDay = day,
                dobMonth = month,
                dobYear = year,
                birthHour = hour,
                birthMinute = minute,
                birthAmPm = amPm,
                birthCity = city,
                gender = gender,
                selectedLanguage = _selectedLanguage.value.name
            )
            repository.saveUserProfile(updated)
            _toastMessage.emit("Kundali Profile Safaltapoorvak Save Ho Gayi!")
            _currentRoute.value = ScreenRoute.Home
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            _isAiThinking.value = true
            try {
                repository.sendUserMessageAndGetAiResponse(text, _selectedLanguage.value)
            } finally {
                _isAiThinking.value = false
            }
        }
    }

    fun toggleDarkTheme(isDark: Boolean) {
        viewModelScope.launch {
            repository.updateDarkTheme(isDark)
        }
    }

    fun getDailyHoroscope(): DailyHoroscope {
        return repository.getDailyHoroscope(userProfile.value, _selectedMood.value, _selectedLanguage.value)
    }

    fun getMarriagePrediction(): MarriagePrediction {
        return repository.getMarriagePrediction(userProfile.value, _selectedLanguage.value)
    }
}
