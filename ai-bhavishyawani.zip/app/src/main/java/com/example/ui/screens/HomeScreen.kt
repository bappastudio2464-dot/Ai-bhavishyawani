package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TransitAlert
import com.example.ui.components.PanchangCard
import com.example.ui.components.RakshaYantraCard
import com.example.ui.theme.CelestialEmerald
import com.example.ui.theme.CosmicPurpleSecondary
import com.example.ui.theme.MysticGoldPrimary
import com.example.ui.viewmodel.AstrologyViewModel
import com.example.ui.viewmodel.ScreenRoute
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(viewModel: AstrologyViewModel) {
    val profile by viewModel.userProfile.collectAsState()
    val selectedMood by viewModel.selectedMood.collectAsState()
    val transitAlerts by viewModel.transitAlerts.collectAsState()
    val horoscope = viewModel.getDailyHoroscope()

    val userName = profile?.name?.ifBlank { "User" } ?: "User"
    val userRashi = profile?.rashi ?: "Aries (Mesh)"

    val currentDateTimeStr = remember {
        SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
    }

    var showTransitDialog by remember { mutableStateOf<TransitAlert?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Daily Siddha Raksha Yantra Card (Top of Screen)
        RakshaYantraCard()

        // Profile Incomplete Warning Banner if profile not fully onboarded
        if (profile == null || !profile!!.isOnboarded || profile!!.name.isBlank()) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "⚠️ Profile Details Adhuri Hain!",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = "100% Sahi Kundali v Vivah Prediction ke liye pehle apni poori Janm Details bharein.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.9f)
                        )
                    }
                    Button(
                        onClick = { viewModel.navigateTo(ScreenRoute.Onboarding) },
                        colors = ButtonDefaults.buttonColors(containerColor = MysticGoldPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Fill Now", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Hero Astrology Banner Card with Accurate Date & Time
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_astrology_1785914270917),
                    contentDescription = "Cosmic Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .clip(RoundedCornerShape(24.dp))
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f))
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MysticGoldPrimary
                        ) {
                            Text(
                                text = "Dainik Rashifal • $userRashi",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = "📅 $currentDateTimeStr",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Namaste, $userName Ji! 🙏",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )

                    Text(
                        text = horoscope.summaryText,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Mood Selector Section
        Column {
            Text(
                text = "Aaj aapka mood kaisa hai? (Personal Guidance)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MysticGoldPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))

            val moods = listOf(
                "Happy" to "😊 Khush",
                "Anxious" to "😟 Chinta",
                "Career Seeking" to "💼 Career/Job",
                "Relationship" to "❤️ Love/Shadi",
                "Financial" to "💰 Dhan/Money"
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(moods) { (key, label) ->
                    val isSelected = selectedMood == key
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setMood(key) },
                        label = {
                            Text(
                                text = label,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MysticGoldPrimary,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Mood Guidance Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Mood Guidance",
                        tint = MysticGoldPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = horoscope.moodGuidance,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Detailed Today's Horoscope Breakdown (Overview, Hurdles, Remedies)
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "⭐ Aj Ka Rashifal & Niwaran ($userRashi)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CelestialEmerald.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "Shubh Marks: 85%",
                            style = MaterialTheme.typography.labelSmall,
                            color = CelestialEmerald,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 1. Din Kaisa Rahega
                Text(
                    text = "🌞 1. Aj Ka Din Kaisa Rahega (Today's Overview):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = horoscope.overviewText,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                )

                // 2. Muskil & Caution
                Text(
                    text = "⚠️ 2. Aj Kya Muskil Aa Sakti Hai (Caution & Hurdles):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFF87171)
                )
                Text(
                    text = horoscope.hurdlesText,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                )

                // 3. Upay & Niwaran
                Text(
                    text = "🪔 3. Roj Ka Siddha Upay & Niwaran (Daily Remedy):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = CelestialEmerald
                )
                Text(
                    text = horoscope.remedyText,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
                )
            }
        }

        // Core Astrology Features Grid
        Text(
            text = "Mukhya Sevaayein (Key Astrology Services)",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Janam Kundali & Gun Milan
            FeatureCard(
                title = "Janam Kundali & Matching",
                subtitle = "Kundali PDF/JPG & Gun Milan",
                icon = Icons.Default.GridView,
                badgeText = "Export PDF",
                onClick = { viewModel.navigateTo(ScreenRoute.Kundali) },
                modifier = Modifier.weight(1f)
            )

            // AI Jyotish Assistant
            FeatureCard(
                title = "AI Astrologer Chat",
                subtitle = "Live Internet Upay & Remedies",
                icon = Icons.Default.SmartToy,
                badgeText = "24/7 AI",
                onClick = { viewModel.navigateTo(ScreenRoute.AiChat) },
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Mantra Today
            FeatureCard(
                title = "Dainik Mantra & Jaap",
                subtitle = "Dhan Prapti Mantra & 108 Jaap",
                icon = Icons.Default.SelfImprovement,
                badgeText = "Audio Play",
                onClick = { viewModel.navigateTo(ScreenRoute.Mantra) },
                modifier = Modifier.weight(1f)
            )

            // Vivah Prediction
            FeatureCard(
                title = "Vivah Yog Prediction",
                subtitle = "Shadi Kab & Kisse Hogi?",
                icon = Icons.Default.Favorite,
                badgeText = "Marriage",
                onClick = { viewModel.navigateTo(ScreenRoute.MarriagePrediction) },
                modifier = Modifier.weight(1f)
            )
        }

        // Aaj Ka Panchang Card
        PanchangCard()

        // Daily Planetary Transit Alerts
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Graha Gochar & Transit Alerts",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MysticGoldPrimary
                )
                Text(
                    text = "${transitAlerts.size} Alerts",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            transitAlerts.take(3).forEach { alert ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clickable { showTransitDialog = alert }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (alert.impactLevel == "HIGH_POSITIVE") CelestialEmerald.copy(alpha = 0.2f) else MysticGoldPrimary.copy(alpha = 0.2f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.NotificationsActive,
                                    contentDescription = "Alert",
                                    tint = if (alert.impactLevel == "HIGH_POSITIVE") CelestialEmerald else MysticGoldPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = alert.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = alert.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "View",
                            tint = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // Siddha Remedies Button
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MysticGoldPrimary.copy(alpha = 0.5f)),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateTo(ScreenRoute.Remedies) }
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = "Upay",
                    tint = MysticGoldPrimary,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Siddha Samadhan & Upay (Remedies)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )
                    Text(
                        text = "Lal Kitab, Mantras, Gemstones, Daan & Fasting guide",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Open Remedies",
                    tint = MysticGoldPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // Transit Alert Dialog
    showTransitDialog?.let { alert ->
        AlertDialog(
            onDismissRequest = { showTransitDialog = null },
            icon = {
                Icon(
                    Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = MysticGoldPrimary
                )
            },
            title = {
                Text(
                    text = alert.title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Column {
                    Text(
                        text = alert.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "✨ Recommended Remedy / Upay:",
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = alert.remedyAdvice,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showTransitDialog = null }) {
                    Text("Samajh Gaya (OK)", color = MysticGoldPrimary)
                }
            }
        )
    }
}

@Composable
private fun FeatureCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badgeText: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = MysticGoldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MysticGoldPrimary.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = badgeText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MysticGoldPrimary,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.8f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
