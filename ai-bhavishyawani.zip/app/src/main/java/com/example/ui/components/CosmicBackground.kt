package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

@Composable
fun CosmicBackground(
    isDarkTheme: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val gradientBrush = if (isDarkTheme) {
        Brush.verticalGradient(
            colors = listOf(
                CosmicBackgroundDark,
                CosmicSurfaceDark,
                CosmicSurfaceVariantDark,
                CosmicBackgroundDark
            )
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(
                CosmicBackgroundLight,
                CosmicSurfaceLight,
                CosmicSurfaceVariantLight,
                CosmicBackgroundLight
            )
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradientBrush)
    ) {
        content()
    }
}
