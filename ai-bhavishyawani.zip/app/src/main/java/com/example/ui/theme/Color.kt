package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Navy Blue Cosmic Backgrounds
val CosmicBackgroundDark = Color(0xFF0A192F)
val CosmicSurfaceDark = Color(0xFF112240)
val CosmicSurfaceVariantDark = Color(0xFF1E3A8A)
val CosmicCardDark = Color(0xFF172A45)

// Electric Cyan Blue Accents (Replacing Yellow with Vibrant Cyan/Blue)
val MysticGoldPrimary = Color(0xFF38BDF8) // Vibrant Sky Blue/Cyan accent
val MysticGoldVariant = Color(0xFF0284C7)
val MysticGoldContainer = Color(0xFF0369A1)
val OnMysticGold = Color(0xFFFFFFFF)

// Secondary Accents
val CosmicPurpleSecondary = Color(0xFF60A5FA)
val CosmicIndigoTertiary = Color(0xFF2563EB)
val CelestialEmerald = Color(0xFF34D399)
val CosmicRedAccent = Color(0xFFF87171)

// Light Palette
val CosmicBackgroundLight = Color(0xFF0F2027)
val CosmicSurfaceLight = Color(0xFF203A43)
val CosmicSurfaceVariantLight = Color(0xFF2C5364)
val CosmicPurplePrimaryLight = Color(0xFF38BDF8)
val OnCosmicLightText = Color(0xFFFFFFFF)


