package com.example.ui.screens

import android.media.AudioManager
import android.media.ToneGenerator
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CelestialEmerald
import com.example.ui.theme.CosmicPurpleSecondary
import com.example.ui.theme.MysticGoldPrimary
import com.example.ui.viewmodel.AstrologyViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DailyMantra(
    val dayName: String,
    val deityName: String,
    val purpose: String,
    val sanskritMantra: String,
    val hindiMeaning: String,
    val englishMeaning: String,
    val benefitText: String,
    val recommendedCount: Int = 108
)

data class JaapResetLog(
    val id: Int,
    val mantraName: String,
    val finalCount: Long,
    val durationSeconds: Long,
    val formattedDate: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MantraScreen(viewModel: AstrologyViewModel) {
    val context = LocalContext.current

    var mainTab by remember { mutableIntStateOf(0) } // 0: Unlimited Circle Counter, 1: Daily Panchang Mantra

    // Audio Chime Tone Generator
    val toneGenerator = remember {
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 70)
        } catch (e: Exception) {
            null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Tab Navigation Header
        TabRow(
            selectedTabIndex = mainTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MysticGoldPrimary,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
        ) {
            Tab(
                selected = mainTab == 0,
                onClick = { mainTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Unlimited Circle Counter", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            )
            Tab(
                selected = mainTab == 1,
                onClick = { mainTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.SelfImprovement, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Dainik Mantra", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            )
        }

        when (mainTab) {
            0 -> UnlimitedCircleCounterTab(toneGenerator = toneGenerator)
            1 -> DailyVedicMantraTab(toneGenerator = toneGenerator)
        }
    }
}

@Composable
private fun UnlimitedCircleCounterTab(toneGenerator: ToneGenerator?) {
    val context = LocalContext.current

    // Preset Mantras
    val presetMantras = listOf(
        "Radha Radha (राधा राधा)",
        "Ram Ram (राम राम)",
        "Hare Krishna (हरे कृष्णा)",
        "Om Namah Shivaya (ॐ नमः शिवाय)",
        "Jai Shri Ram (जय श्री राम)",
        "Om Ghrini Suryaya Namah (ॐ घृणिः सूर्याय नमः)"
    )

    var selectedMantraName by remember { mutableStateOf("Radha Radha (राधा राधा)") }
    var customMantraText by remember { mutableStateOf("") }
    var isCustomSelected by remember { mutableStateOf(false) }

    var jaapCounter by remember { mutableLongStateOf(0L) }
    var isTimerRunning by remember { mutableStateOf(false) }
    var elapsedSeconds by remember { mutableLongStateOf(0L) }

    val resetHistory = remember { mutableStateListOf<JaapResetLog>() }

    // Live Timer Coroutine Effect
    LaunchedEffect(isTimerRunning) {
        while (isTimerRunning) {
            delay(1000L)
            elapsedSeconds++
        }
    }

    val activeMantraDisplay = if (isCustomSelected) {
        customMantraText.ifBlank { "Radha Radha" }
    } else {
        selectedMantraName
    }

    // Formatted Timer String (HH:MM:SS or MM:SS)
    val hours = elapsedSeconds / 3600
    val minutes = (elapsedSeconds % 3600) / 60
    val secs = elapsedSeconds % 60
    val timerFormatted = if (hours > 0) {
        String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, secs)
    } else {
        String.format(Locale.getDefault(), "%02d:%02d", minutes, secs)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Card: Select Naam / Mantra
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "🌸 Select Chanting Naam (नाम/मंत्र चुनें):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MysticGoldPrimary
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(presetMantras) { mantra ->
                        val isSelected = !isCustomSelected && selectedMantraName == mantra
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                isCustomSelected = false
                                selectedMantraName = mantra
                            },
                            label = { Text(mantra, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MysticGoldPrimary,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }

                    item {
                        FilterChip(
                            selected = isCustomSelected,
                            onClick = { isCustomSelected = true },
                            label = { Text("✏️ Custom Naam", fontWeight = if (isCustomSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MysticGoldPrimary,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }

                if (isCustomSelected) {
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = customMantraText,
                        onValueChange = { customMantraText = it },
                        label = { Text("Mantra / Bhagwan Ka Naam (e.g. Radhe Radhe)") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Timer & Live Count Card
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, MysticGoldPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header: Active Mantra Name & Live Timer
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = activeMantraDisplay,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MysticGoldPrimary
                        )
                        Text(
                            text = "Unlimited Circle Tap Jaap",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.Black.copy(alpha = 0.4f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CelestialEmerald)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Timer",
                                tint = CelestialEmerald,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = timerFormatted,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = CelestialEmerald
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // GIANT GOLDEN CIRCULAR TAP BUTTON
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(180.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    MysticGoldPrimary,
                                    MysticGoldPrimary.copy(alpha = 0.7f),
                                    Color(0xFFB8860B)
                                )
                            )
                        )
                        .border(4.dp, Color.White, CircleShape)
                        .clickable {
                            // Start timer on first tap
                            if (!isTimerRunning) {
                                isTimerRunning = true
                            }
                            jaapCounter++
                            try {
                                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
                            } catch (_: Exception) {
                            }
                        }
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$jaapCounter",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.Black,
                            fontSize = 38.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = "Tap",
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "+1 TAP JAAP",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Reset Button & Session Save
                Button(
                    onClick = {
                        if (jaapCounter > 0) {
                            val timeStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())
                            val newLog = JaapResetLog(
                                id = resetHistory.size + 1,
                                mantraName = activeMantraDisplay,
                                finalCount = jaapCounter,
                                durationSeconds = elapsedSeconds,
                                formattedDate = timeStr
                            )
                            resetHistory.add(0, newLog)
                            Toast.makeText(context, "Counter Reset! $jaapCounter Jaap history me save ho gaya.", Toast.LENGTH_SHORT).show()
                        }
                        jaapCounter = 0L
                        isTimerRunning = false
                        elapsedSeconds = 0L
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reset Counter & Save Session (रीसेट करें)", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        // Pichla Reset History Section (Previous Reset Logs)
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "📜 Pichla Reset History Log (इतिहास):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MysticGoldPrimary
                )
                if (resetHistory.isNotEmpty()) {
                    TextButton(onClick = { resetHistory.clear() }) {
                        Text("Clear Logs", color = MaterialTheme.colorScheme.outline)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (resetHistory.isEmpty()) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier.padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Abhi koi reset history nahi hai. Jaap shuru karein aur reset karne par pichla counter yahan dikhai dega.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                resetHistory.forEach { log ->
                    val h = log.durationSeconds / 3600
                    val m = (log.durationSeconds % 3600) / 60
                    val s = log.durationSeconds % 60
                    val durStr = if (h > 0) "${h}h ${m}m ${s}s" else "${m}m ${s}s"

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Reset #${log.id}: ${log.mantraName}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Samay: ${log.formattedDate} • Duration: $durStr",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MysticGoldPrimary
                            ) {
                                Text(
                                    text = "✨ ${log.finalCount} Count",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun DailyVedicMantraTab(toneGenerator: ToneGenerator?) {
    val context = LocalContext.current

    // Determine Mantra based on Day of Week
    val dayOfWeek = remember { Calendar.getInstance().get(Calendar.DAY_OF_WEEK) }
    val mantra = remember(dayOfWeek) { getMantraForDay(dayOfWeek) }

    var jaapCount by remember { mutableIntStateOf(0) }
    var isPlayingAudio by remember { mutableStateOf(false) }
    var isAutoJaap by remember { mutableStateOf(false) }

    // Auto-Jaap & Audio Loop Effect
    LaunchedEffect(isPlayingAudio, isAutoJaap, jaapCount) {
        if (isPlayingAudio || isAutoJaap) {
            if (jaapCount < 108) {
                delay(2500)
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 200)
                } catch (_: Exception) {
                }
                if (isAutoJaap && jaapCount < 108) {
                    jaapCount++
                }
            } else {
                isPlayingAudio = false
                isAutoJaap = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Banner: Panchang Mantra of the Day
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                CosmicPurpleSecondary.copy(alpha = 0.4f),
                                MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MysticGoldPrimary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Text(
                            text = "Dainik Panchang Mantra • ${mantra.dayName}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }

                    Text(
                        text = "Mantra For Today (${mantra.purpose})",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "Pujya Bhagwan: ${mantra.deityName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MysticGoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Sanskrit Mantra Main Card
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(2.dp, MysticGoldPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "🌸 Sanskrit Vedic Mantra 🌸",
                    style = MaterialTheme.typography.labelSmall,
                    color = MysticGoldPrimary,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Devanagari Sanskrit Mantra Display
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier.padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mantra.sanskritMantra,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            lineHeight = 36.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Audio Chanting Player Button
                Button(
                    onClick = {
                        isPlayingAudio = !isPlayingAudio
                        if (isPlayingAudio) {
                            try {
                                toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 300)
                            } catch (_: Exception) {
                            }
                            Toast.makeText(context, "Mantra audio chanting start ho gayi...", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPlayingAudio) CelestialEmerald else MysticGoldPrimary
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = if (isPlayingAudio) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                            contentDescription = "Audio Play",
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isPlayingAudio) "Stop Audio Chant" else "Play Audio Mantra (Suno)",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (isPlayingAudio) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "🔊 Mantra chanting audio is playing...",
                        style = MaterialTheme.typography.bodySmall,
                        color = CelestialEmerald,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Hindi & English Meanings Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "🇮🇳 Hindi Arth (Meaning in Hindi):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MysticGoldPrimary
                )
                Text(
                    text = mantra.hindiMeaning,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )

                Divider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "🇬🇧 English Meaning:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MysticGoldPrimary
                )
                Text(
                    text = mantra.englishMeaning,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CelestialEmerald.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Benefits",
                            tint = CelestialEmerald,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = mantra.benefitText,
                            style = MaterialTheme.typography.bodySmall,
                            color = CelestialEmerald,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // 108 Japa Counter Section
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "📿 108 Jaap Counter (Rudraksha Mala)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    TextButton(onClick = { jaapCount = 0 }) {
                        Text("Reset", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Progress Indicator Ring & Count Display
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(140.dp)
                ) {
                    CircularProgressIndicator(
                        progress = (jaapCount / 108f).coerceIn(0f, 1f),
                        strokeWidth = 10.dp,
                        color = MysticGoldPrimary,
                        trackColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxSize()
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$jaapCount",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        Text(
                            text = "/ 108 Times",
                            style = MaterialTheme.typography.labelMedium,
                            color = MysticGoldPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Large Jaap Tap Button
                Button(
                    onClick = {
                        if (jaapCount < 108) {
                            jaapCount++
                            try {
                                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 100)
                            } catch (_: Exception) {
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MysticGoldPrimary),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(100.dp)
                        .padding(4.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.TouchApp,
                            contentDescription = "Tap Jaap",
                            tint = Color.Black,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "+1 Jaap",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Auto-Jaap Switch Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Auto 108 Jaap (Automated Counter)",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = isAutoJaap,
                        onCheckedChange = { isAutoJaap = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MysticGoldPrimary)
                    )
                }

                if (jaapCount >= 108) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = CelestialEmerald,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.WorkspacePremium, contentDescription = "Done", tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "✨ 108 Jaap Sampanna! Bhagwan ka Aashirwad prapt hua. 🙏",
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

private fun getMantraForDay(dayOfWeek: Int): DailyMantra {
    return when (dayOfWeek) {
        Calendar.SUNDAY -> DailyMantra(
            dayName = "Ravivar (Sunday)",
            deityName = "Surya Dev (Sun God)",
            purpose = "Tejas, Aarogya & Dhan Prapti",
            sanskritMantra = "ॐ ह्रां ह्रीं ह्रौं सः सूर्याय नमः ॥",
            hindiMeaning = "हे भुवनभास्कर सूर्यदेव! मैं आपको प्रणाम करता हूँ। मुझे आरोग्य, धन, यश और तेजस्विता प्रदान करें।",
            englishMeaning = "O Lord Surya, illuminator of the universe! I bow to you. Bestow upon me health, prosperity, fame, and divine brilliance.",
            benefitText = "Surya Arghya ke saath 108 baar jaap karne se samaj me man-samman aur dhan vridhi hoti hai."
        )

        Calendar.MONDAY -> DailyMantra(
            dayName = "Somvar (Monday)",
            deityName = "Bhagwan Shiv (Lord Shiva)",
            purpose = "Mansi Shanti & Dhan Prapti",
            sanskritMantra = "ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम् ।\nउर्वारुकमिव बन्धनान्मृत्योर्मुक्षीय माऽमृतात् ॥",
            hindiMeaning = "हम तीन नेत्रों वाले भगवान शिव की पूजा करते हैं, जो समस्त जीवों का पोषण करते हैं। हमें मोक्ष और सुख-शांति प्रदान करें।",
            englishMeaning = "We worship the three-eyed Lord Shiva who nourishes all beings. May He liberate us and grant eternal peace and prosperity.",
            benefitText = "Somvar ko Shivling par jal chadakar 108 baar jaap karne se sabhi kast aur daridrata door hoti hai."
        )

        Calendar.TUESDAY -> DailyMantra(
            dayName = "Mangalvar (Tuesday)",
            deityName = "Shri Hanuman Ji",
            purpose = "Sankat Mochan & Samriddhi Prapti",
            sanskritMantra = "ॐ हं हनुमते रुद्रात्मकाय हुं फट् ॥",
            hindiMeaning = "रुद्रावतार श्री हनुमान जी महाराज को नमन है। हमारे समस्त संकटों का नाश कर सुख और समृद्धि प्रदान करें।",
            englishMeaning = "Salutations to Lord Hanuman, the incarnation of Lord Shiva. Remove all our obstacles and grant courage and success.",
            benefitText = "Mangalvar ko Chola chadakar jaap karne se bhay, shatru aur dhan ki samasya samapt hoti hai."
        )

        Calendar.WEDNESDAY -> DailyMantra(
            dayName = "Budhvar (Wednesday)",
            deityName = "Bhagwan Ganesha (Lord Ganesha)",
            purpose = "Riddhi-Siddhi & Vyapar Dhan Prapti",
            sanskritMantra = "ॐ गं गणपतये नमो नमः ।\nश्री सिद्धिविनायक नमो नमः ॥",
            hindiMeaning = "विघ्नहर्ता श्री गणेश जी को बारंबार प्रणाम है। हमारे बुद्धि, व्यापार और घर में सुख-समृद्धि का वास हो।",
            englishMeaning = "Salutations to Lord Ganesha, the remover of obstacles and granter of spiritual and material success.",
            benefitText = "Budhvar ko Doob va Laddoo arpan karke jaap karne se buddhi, career aur vyapar me apar dhan milta hai."
        )

        Calendar.THURSDAY -> DailyMantra(
            dayName = "Guruvar (Thursday)",
            deityName = "Bhagwan Vishnu & Guru Brihaspati",
            purpose = "Lakshmi-Narayan Dhan & Vivah Prapti",
            sanskritMantra = "ॐ नमो भगवते वासुदेवाय ॥\nॐ ग्रां ग्रीं ग्रौं सः गुरुवे नमः ॥",
            hindiMeaning = "सर्वव्यापी भगवान विष्णु और बृहस्पति देव को नमन है। हमें ज्ञान, उत्तम विवाह योग और अखंड धन-धान्य प्रदान करें।",
            englishMeaning = "I bow to Supreme Lord Vasudeva and Jupiter. Bestow upon us wisdom, auspicious marriage alignment, and everlasting wealth.",
            benefitText = "Kela vriksh ki pooja ke saath 108 baar jaap karne se shadi me aa rahi rukaawat door hoti hai aur dhan labh hota hai."
        )

        Calendar.FRIDAY -> DailyMantra(
            dayName = "Shukravar (Friday)",
            deityName = "Maa Mahalakshmi",
            purpose = "Akhand Dhan & Samriddhi Prapti",
            sanskritMantra = "ॐ श्रीं ह्रीं श्रीं कमले कमलालये प्रसीद प्रसीद ।\nॐ श्रीं ह्रीं श्रीं महालक्ष्म्यै नमः ॥",
            hindiMeaning = "हे कमलवासिनी माँ महालक्ष्मी! मुझ पर प्रसन्न होइए और मेरे गृह में अक्षय धन, वैभव और समृद्धि का वास कराइए।",
            englishMeaning = "O Goddess Mahalakshmi who resides on the lotus! Be pleased with me and bless my home with eternal wealth, glory, and harmony.",
            benefitText = "Shukravar ki sandhya me Ghee ka deepak jalakar jaap karne se daridrata sada ke liye samapt hoti hai."
        )

        else -> DailyMantra(
            dayName = "Shanivar (Saturday)",
            deityName = "Shani Dev & Lord Hanuman",
            purpose = "Raksha & Shanti Prapti",
            sanskritMantra = "ॐ शं शनैश्चराय नमः ॥\nॐ श्री हनुमते नमः ॥",
            hindiMeaning = "न्यायप्रिय शनिदेव और हनुमान जी महाराज को प्रणाम है। हमारे ग्रह दोषों को शांत कर रक्षा और सुख-शांति प्रदान करें।",
            englishMeaning = "Salutations to Lord Shani and Lord Hanuman. Pacific planetary afflictions and grant divine protection and peace.",
            benefitText = "Shanivar ko Shami vriksh ya Peepal ke neeche tel ka deepak jalakar jaap karne se Raksha hoti hai."
        )
    }
}
