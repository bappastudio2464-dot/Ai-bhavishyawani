package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CelestialEmerald
import com.example.ui.theme.MysticGoldPrimary
import com.example.util.StorageExporter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RakshaYantraCard() {
    val context = LocalContext.current
    val todayDateStr = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, MysticGoldPrimary),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Raksha Yantra",
                    tint = MysticGoldPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Dainik Siddha Raksha Yantra • $todayDateStr",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MysticGoldPrimary
                )
            }

            Text(
                text = "Buri Nazar, Graha Dosha & Rahu-Ketu Shanti Suraksha Kavach",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
            )

            // Canvas Sacred Yantra Geometry Visual
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(1.dp, MysticGoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val center = Offset(w / 2f, h / 2f)

                    // Outer Square
                    drawRect(
                        color = Color(0xFF38BDF8),
                        topLeft = Offset(40f, 20f),
                        size = androidx.compose.ui.geometry.Size(w - 80f, h - 40f),
                        style = Stroke(width = 3f)
                    )

                    // Concentric Circles
                    drawCircle(color = Color(0xFF60A5FA), center = center, radius = 70f, style = Stroke(width = 2f))
                    drawCircle(color = Color(0xFF38BDF8), center = center, radius = 50f, style = Stroke(width = 3f))

                    // Diagonal Star Lines
                    drawLine(color = Color(0xFF38BDF8).copy(alpha = 0.6f), start = Offset(60f, 30f), end = Offset(w - 60f, h - 30f), strokeWidth = 1.5f)
                    drawLine(color = Color(0xFF38BDF8).copy(alpha = 0.6f), start = Offset(w - 60f, 30f), end = Offset(60f, h - 30f), strokeWidth = 1.5f)
                }

                // Inner Seed Mantras
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("श्रीं ॐ ह्रीं", fontWeight = FontWeight.ExtraBold, color = MysticGoldPrimary, fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("ॐ सर्वरक्षा कुरु स्वाहा", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("क्लीं ॐ शं", fontWeight = FontWeight.ExtraBold, color = CelestialEmerald, fontSize = 18.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Export Buttons: Save JPG & Download PDF
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Save JPG to Gallery
                Button(
                    onClick = {
                        val lines = listOf(
                            "Dainik Siddha Raksha Yantra Kavach",
                            "Date: $todayDateStr",
                            "Seed Mantras: श्रीं ॐ ह्रीं - क्लीं ॐ शं",
                            "Usage: Is Yantra ko Mobile Gallery me save karke",
                            "prati din pratah darshan karne se sabhi graha dosha",
                            "aur buri nazar se suraksha prapt hoti hai."
                        )
                        StorageExporter.saveJpgToGallery(context, "Siddha Raksha Yantra", lines, "Raksha_Yantra")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MysticGoldPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Download, contentDescription = "Save JPG", tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save JPG", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // Download PDF
                Button(
                    onClick = {
                        val content = listOf(
                            "==================================================",
                            "Dainik Siddha Raksha Yantra Report",
                            "Date: $todayDateStr",
                            "==================================================",
                            "Sanskrit Kavach Mantra:",
                            "  ॐ श्रीं ह्रीं क्लीं सर्वविघ्नविनाशिने नमः",
                            "",
                            "Yantra Benefits:",
                            "• Rahu-Ketu and Shani planet obstacle removal",
                            "• Negative energy and evil eye protection",
                            "• Financial security and home harmony",
                            "",
                            "Instruction:",
                            "Keep this downloaded PDF in your device storage or print",
                            "it for your home altar."
                        )
                        StorageExporter.savePdfToStorage(context, "Dainik Raksha Yantra PDF", content, "Raksha_Yantra_PDF")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Download PDF", tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save PDF", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
