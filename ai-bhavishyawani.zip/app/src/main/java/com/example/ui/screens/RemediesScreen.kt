package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CelestialEmerald
import com.example.ui.theme.MysticGoldPrimary
import com.example.ui.viewmodel.AstrologyViewModel

data class RemedyCategory(
    val title: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val remedies: List<String>
)

@Composable
fun RemediesScreen(viewModel: AstrologyViewModel) {
    val categories = listOf(
        RemedyCategory(
            title = "Vivah & Relationship Upay",
            subtitle = "For early marriage & marital harmony",
            icon = Icons.Default.Favorite,
            remedies = listOf(
                "Har Guruvar ko Tulsi vriksh aur Kela vriksh par haldi mishrit jal arpan karein.",
                "Gauri Shankar Rudraksha dharan karein for emotional bonding with spouse.",
                "Friday (Shukravar) ko safed mithaai choti kanyaon me baantein."
            )
        ),
        RemedyCategory(
            title = "Career & Job Promotion Upay",
            subtitle = "For business growth & job stability",
            icon = Icons.Default.Work,
            remedies = listOf(
                "Subah Surya Dev ko Tambe (Copper) ke lotey se jal arghya dein.",
                "Saturday ko Peepal tree ke neeche sarson ke tel ka diya jalayein.",
                "Karya sthal par Sphatik Shree Yantra sthapit karein."
            )
        ),
        RemedyCategory(
            title = "Siddha Gemstone Guidance (Ratna)",
            subtitle = "Natural Gemstones based on Rashi",
            icon = Icons.Default.Diamond,
            remedies = listOf(
                "Pukhraj (Yellow Sapphire): Guru Graha balwan karne ke liye Gold ring me dharan karein.",
                "Panna (Emerald): Budh Graha vyapar me unnati aur dimaag shant rakhne ke liye.",
                "Moti (Pearl): Chandra Graha mental peace aur stress kam karne ke liye."
            )
        ),
        RemedyCategory(
            title = "Powerful Daily Mantras",
            subtitle = "108 Times daily recitation",
            icon = Icons.Default.AutoAwesome,
            remedies = listOf(
                "Mahamrityunjaya Mantra: Om Tryambakam Yajamahe Sugandhim Pushti-Vardhanam...",
                "Gayatri Mantra: Om Bhur Bhuva Swaha...",
                "Katyayani Mantra for Marriage: Om Katyayani Mahamaye Mahayoginyadheeshwari..."
            )
        )
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Siddha Vedic Upay & Samadhan",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )
                    Text(
                        text = "Auspicious Lal Kitab remedies, Mantras, Gemstones & Fasting routines",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        items(categories) { category ->
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MysticGoldPrimary.copy(alpha = 0.2f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = category.icon,
                                    contentDescription = category.title,
                                    tint = MysticGoldPrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = category.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = category.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    category.remedies.forEachIndexed { index, remedy ->
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = "• ",
                                fontWeight = FontWeight.Bold,
                                color = MysticGoldPrimary
                            )
                            Text(
                                text = remedy,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
