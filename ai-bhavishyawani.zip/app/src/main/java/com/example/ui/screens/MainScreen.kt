package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CosmicBackground
import com.example.ui.components.LanguageSelectorDialog
import com.example.ui.theme.MysticGoldPrimary
import com.example.ui.viewmodel.AstrologyViewModel
import com.example.ui.viewmodel.ScreenRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: AstrologyViewModel) {
    val currentRoute by viewModel.currentRoute.collectAsState()
    val profile by viewModel.userProfile.collectAsState()
    val selectedLang by viewModel.selectedLanguage.collectAsState()
    val context = LocalContext.current

    var showLangDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.toastMessage.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    if (currentRoute is ScreenRoute.Onboarding) {
        OnboardingScreen(viewModel = viewModel)
    } else {
        CosmicBackground(isDarkTheme = profile?.isDarkTheme ?: true) {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_app_icon_1785914251615),
                                    contentDescription = "Logo",
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Ai Bhavishyawani",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Vedic Future Insights",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MysticGoldPrimary,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        },
                        actions = {
                            // Language Pill
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .padding(end = 12.dp)
                                    .clickable { showLangDialog = true }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(text = selectedLang.flagEmoji, fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = selectedLang.code.uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        // 1. Home Tab
                        NavigationBarItem(
                            selected = currentRoute is ScreenRoute.Home,
                            onClick = { viewModel.navigateTo(ScreenRoute.Home) },
                            icon = { Icon(Icons.Default.Dashboard, contentDescription = "Home") },
                            label = { Text("Home") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MysticGoldPrimary,
                                selectedTextColor = MysticGoldPrimary,
                                indicatorColor = MysticGoldPrimary.copy(alpha = 0.2f)
                            )
                        )

                        // 2. Mantra Today Tab
                        NavigationBarItem(
                            selected = currentRoute is ScreenRoute.Mantra,
                            onClick = { viewModel.navigateTo(ScreenRoute.Mantra) },
                            icon = { Icon(Icons.Default.SelfImprovement, contentDescription = "Mantra") },
                            label = { Text("Mantra") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MysticGoldPrimary,
                                selectedTextColor = MysticGoldPrimary,
                                indicatorColor = MysticGoldPrimary.copy(alpha = 0.2f)
                            )
                        )

                        // 3. Center Floating AI Chat READ item
                        NavigationBarItem(
                            selected = currentRoute is ScreenRoute.AiChat,
                            onClick = { viewModel.navigateTo(ScreenRoute.AiChat) },
                            icon = {
                                Surface(
                                    shape = CircleShape,
                                    color = MysticGoldPrimary,
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Psychology, contentDescription = "AI Read", tint = Color.Black)
                                    }
                                }
                            },
                            label = { Text("AI Chat", fontWeight = FontWeight.Bold, color = MysticGoldPrimary) }
                        )

                        // 4. Kundali & Gun Milan Match Tab
                        NavigationBarItem(
                            selected = currentRoute is ScreenRoute.Kundali,
                            onClick = { viewModel.navigateTo(ScreenRoute.Kundali) },
                            icon = { Icon(Icons.Default.GridView, contentDescription = "Kundali") },
                            label = { Text("Kundali") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MysticGoldPrimary,
                                selectedTextColor = MysticGoldPrimary,
                                indicatorColor = MysticGoldPrimary.copy(alpha = 0.2f)
                            )
                        )

                        // 5. Profile Tab
                        NavigationBarItem(
                            selected = currentRoute is ScreenRoute.Profile,
                            onClick = { viewModel.navigateTo(ScreenRoute.Profile) },
                            icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Profile") },
                            label = { Text("Profile") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MysticGoldPrimary,
                                selectedTextColor = MysticGoldPrimary,
                                indicatorColor = MysticGoldPrimary.copy(alpha = 0.2f)
                            )
                        )
                    }
                }
            ) { paddingValues ->
                Box(modifier = Modifier.padding(paddingValues)) {
                    when (val route = currentRoute) {
                        is ScreenRoute.Home -> HomeScreen(viewModel = viewModel)
                        is ScreenRoute.Mantra -> MantraScreen(viewModel = viewModel)
                        is ScreenRoute.Kundali -> KundaliScreen(viewModel = viewModel)
                        is ScreenRoute.MarriagePrediction -> MarriageScreen(viewModel = viewModel)
                        is ScreenRoute.AiChat -> AiChatScreen(viewModel = viewModel)
                        is ScreenRoute.Remedies -> RemediesScreen(viewModel = viewModel)
                        is ScreenRoute.Profile -> ProfileScreen(viewModel = viewModel)
                        else -> HomeScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }

    if (showLangDialog) {
        LanguageSelectorDialog(
            currentLanguage = selectedLang,
            onLanguageSelected = { viewModel.setLanguage(it) },
            onDismissRequest = { showLangDialog = false }
        )
    }
}
