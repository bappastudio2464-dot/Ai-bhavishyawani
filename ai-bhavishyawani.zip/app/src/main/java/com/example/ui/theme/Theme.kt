package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MysticGoldPrimary,
    onPrimary = Color.White,
    primaryContainer = MysticGoldContainer,
    onPrimaryContainer = Color.White,
    secondary = CosmicPurpleSecondary,
    onSecondary = Color.White,
    secondaryContainer = CosmicIndigoTertiary,
    onSecondaryContainer = Color.White,
    tertiary = CelestialEmerald,
    onTertiary = Color.White,
    background = CosmicBackgroundDark,
    onBackground = Color.White,
    surface = CosmicSurfaceDark,
    onSurface = Color.White,
    surfaceVariant = CosmicSurfaceVariantDark,
    onSurfaceVariant = Color(0xFFE2E8F0)
)

private val LightColorScheme = darkColorScheme(
    primary = MysticGoldPrimary,
    onPrimary = Color.White,
    primaryContainer = MysticGoldContainer,
    onPrimaryContainer = Color.White,
    secondary = CosmicPurpleSecondary,
    onSecondary = Color.White,
    tertiary = CelestialEmerald,
    onTertiary = Color.White,
    background = CosmicBackgroundDark,
    onBackground = Color.White,
    surface = CosmicSurfaceDark,
    onSurface = Color.White,
    surfaceVariant = CosmicSurfaceVariantDark,
    onSurfaceVariant = Color(0xFFE2E8F0)
)

@Composable
fun AiBhavishyawaniTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

