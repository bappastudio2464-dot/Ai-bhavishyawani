package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.LanguageSelectorDialog
import com.example.ui.theme.MysticGoldPrimary
import com.example.ui.viewmodel.AstrologyViewModel

@Composable
fun ProfileScreen(viewModel: AstrologyViewModel) {
    val profile by viewModel.userProfile.collectAsState()
    val selectedLang by viewModel.selectedLanguage.collectAsState()
    var showLangDialog by remember { mutableStateOf(false) }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            // Profile Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MysticGoldPrimary,
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = profile?.name?.take(1)?.uppercase() ?: "U",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = profile?.name?.ifBlank { "User Profile" } ?: "User Profile",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Text(
                        text = "Rashi: ${profile?.rashi ?: "Aries"} • Sun: ${profile?.sunSign ?: "Aries"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MysticGoldPrimary,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = "Janm: ${profile?.dobDay}/${profile?.dobMonth}/${profile?.dobYear} at ${profile?.birthCity}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.navigateTo(com.example.ui.viewmodel.ScreenRoute.Onboarding) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = MysticGoldPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Edit Birth Details", color = Color.White)
                    }
                }
            }
        }

        item {
            // Settings Options (Language & Dark Theme)
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    // Language option
                    ListItem(
                        headlineContent = { Text("App Language / भाषा", fontWeight = FontWeight.SemiBold, color = Color.White) },
                        supportingContent = { Text("${selectedLang.displayName} (${selectedLang.nativeName})", color = Color.White.copy(alpha = 0.8f)) },
                        leadingContent = { Icon(Icons.Default.Translate, contentDescription = "Language", tint = MysticGoldPrimary) },
                        trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = "Select", tint = Color.White) },
                        modifier = Modifier.clickable { showLangDialog = true }
                    )

                    Divider(color = MaterialTheme.colorScheme.outlineVariant)

                    // Dark Theme Toggle
                    val isDark = profile?.isDarkTheme ?: true
                    ListItem(
                        headlineContent = { Text("Visually Calming Dark Theme", fontWeight = FontWeight.SemiBold, color = Color.White) },
                        supportingContent = { Text(if (isDark) "Active" else "Light Mode", color = Color.White.copy(alpha = 0.8f)) },
                        leadingContent = { Icon(Icons.Default.DarkMode, contentDescription = "Theme", tint = MysticGoldPrimary) },
                        trailingContent = {
                            Switch(
                                checked = isDark,
                                onCheckedChange = { viewModel.toggleDarkTheme(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = MysticGoldPrimary)
                            )
                        }
                    )
                }
            }
        }
    }

    if (showLangDialog) {
        LanguageSelectorDialog(
            currentLanguage = selectedLang,
            onLanguageSelected = { viewModel.setLanguage(it) },
            onDismissRequest = { showLangDialog = false }
        )
    }
}
