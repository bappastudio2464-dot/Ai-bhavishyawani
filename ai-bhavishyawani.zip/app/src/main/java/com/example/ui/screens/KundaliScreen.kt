package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DoshaAnalysis
import com.example.data.model.PlanetPosition
import com.example.ui.theme.CelestialEmerald
import com.example.ui.theme.CosmicPurpleSecondary
import com.example.ui.theme.CosmicRedAccent
import com.example.ui.theme.MysticGoldPrimary
import com.example.ui.viewmodel.AstrologyViewModel
import com.example.ui.viewmodel.ScreenRoute
import com.example.util.StorageExporter

@Composable
fun KundaliScreen(viewModel: AstrologyViewModel) {
    val profile by viewModel.userProfile.collectAsState()
    val context = LocalContext.current

    val rashi = profile?.rashi ?: "Aries (Mesh)"
    val sunSign = profile?.sunSign ?: "Aries"
    val city = profile?.birthCity ?: "New Delhi"
    val timeStr = "${profile?.birthHour}:${profile?.birthMinute} ${profile?.birthAmPm}"

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Chart, 1: Planets, 2: Doshas & Upay, 3: Shadi Gun Milan

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Warning if birth details are not filled
        if (profile == null || !profile!!.isOnboarded || profile!!.name.isBlank()) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "⚠️ Sahi Kundali ke liye details bharein!",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = "Pehle apna Naam, Janm Tithi & Janm Sthan darj karein.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.9f)
                        )
                    }
                    Button(
                        onClick = { viewModel.navigateTo(ScreenRoute.Onboarding) },
                        colors = ButtonDefaults.buttonColors(containerColor = MysticGoldPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Fill Details", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        // Top Header Info Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${profile?.name?.ifBlank { "User" }} ki Janm Kundali",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MysticGoldPrimary
                        )
                        Text(
                            text = "Janm: ${profile?.dobDay}/${profile?.dobMonth}/${profile?.dobYear} at $timeStr",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                        Text(
                            text = "Sthan: $city • Rashi: $rashi",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }

                    // Kundali PDF & JPG Export Quick Action
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = {
                                val lines = listOf(
                                    "Janm Kundali Report: ${profile?.name?.ifBlank { "User" }}",
                                    "DOB: ${profile?.dobDay}/${profile?.dobMonth}/${profile?.dobYear} ($timeStr)",
                                    "Birth City: $city",
                                    "Rashi: $rashi | Sun Sign: $sunSign",
                                    "Nakshatra: Rohini Pada 2",
                                    "Current Mahadasha: Jupiter (Brihaspati)",
                                    "Vedic Lagna: Taurus Ascendant",
                                    "Rajyoga Status: Active 1st & 7th House Rajyoga"
                                )
                                StorageExporter.saveJpgToGallery(context, "Janam Kundali", lines, "Kundali")
                            }
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Download JPG", tint = MysticGoldPrimary)
                        }

                        IconButton(
                            onClick = {
                                val content = listOf(
                                    "==================================================",
                                    "Official Janam Kundali Report",
                                    "Name: ${profile?.name?.ifBlank { "User" }}",
                                    "==================================================",
                                    "Birth Details:",
                                    "Date of Birth: ${profile?.dobDay}/${profile?.dobMonth}/${profile?.dobYear}",
                                    "Time of Birth: $timeStr",
                                    "Place of Birth: $city",
                                    "Zodiac Moon Sign (Rashi): $rashi",
                                    "Sun Sign: $sunSign",
                                    "",
                                    "Planetary Positions:",
                                    "• Sun (Surya): 1st House (Aries)",
                                    "• Moon (Chandra): 4th House (Cancer)",
                                    "• Mars (Mangal): 7th House (Libra)",
                                    "• Jupiter (Guru): 1st House (Aries)",
                                    "• Venus (Shukra): 5th House (Leo)",
                                    "• Saturn (Shani): 10th House (Capricorn)",
                                    "",
                                    "Auspicious Remedies:",
                                    "• Chant Om Namah Shivaya 108 times daily.",
                                    "• Offer water to Surya Dev every morning."
                                )
                                StorageExporter.savePdfToStorage(context, "Janam Kundali Report PDF", content, "Kundali_Report")
                            }
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = "Download PDF", tint = Color.White)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab Navigation
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MysticGoldPrimary,
            edgePadding = 8.dp,
            modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Lagna Chart", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Grah Stithi", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Dosha & Upay", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                text = { Text("Shadi Gun Milan", fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedTab) {
            0 -> LagnaChartTab(rashi = rashi, sunSign = sunSign)
            1 -> PlanetPositionsTab()
            2 -> DoshasAndUpayTab()
            3 -> GunMilanTab()
        }
    }
}

@Composable
private fun LagnaChartTab(rashi: String, sunSign: String) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Vedic North Indian Kundali Chart",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .border(2.dp, MysticGoldPrimary, RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "1st House (Lagna)",
                                fontWeight = FontWeight.Bold,
                                color = MysticGoldPrimary,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Ascendant: $rashi",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Badge(containerColor = CosmicPurpleSecondary) { Text("Sun (Surya)", color = Color.White) }
                                Badge(containerColor = CelestialEmerald) { Text("Jupiter (Guru)", color = Color.Black) }
                                Badge(containerColor = MysticGoldPrimary) { Text("Venus (Shukra)", color = Color.Black) }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Auspicious Rajyoga Active in 1st & 7th House",
                                style = MaterialTheme.typography.labelSmall,
                                color = CelestialEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Janm Nakshatra & Dasha Summary",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Nakshatra: Rohini Pada 2 (Lord: Moon)",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Text(
                        text = "• Current Mahadasha: Jupiter (Brihaspati) till 2031",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Text(
                        text = "• Antardasha: Venus (Shukra) - Favorable for Marriage & Wealth",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }
    }
}

@Composable
private fun PlanetPositionsTab() {
    val planetList = listOf(
        PlanetPosition("Sun (Surya)", 1, "Aries", false),
        PlanetPosition("Moon (Chandra)", 4, "Cancer", false),
        PlanetPosition("Mars (Mangal)", 7, "Libra", false),
        PlanetPosition("Mercury (Budh)", 2, "Taurus", true),
        PlanetPosition("Jupiter (Guru)", 1, "Aries", false),
        PlanetPosition("Venus (Shukra)", 5, "Leo", false),
        PlanetPosition("Saturn (Shani)", 10, "Capricorn", false),
        PlanetPosition("Rahu", 11, "Aquarius", true),
        PlanetPosition("Ketu", 5, "Leo", true)
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(planetList) { planet ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = planet.planetName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${planet.houseNumber}th House • Rashi: ${planet.rashi}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }

                    if (planet.isRetrograde) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CosmicRedAccent.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "Vakri (Retrograde)",
                                style = MaterialTheme.typography.labelSmall,
                                color = CosmicRedAccent,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = CelestialEmerald.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "Margi (Direct)",
                                style = MaterialTheme.typography.labelSmall,
                                color = CelestialEmerald,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DoshasAndUpayTab() {
    val doshaList = listOf(
        DoshaAnalysis(
            doshaName = "Manglik Dosha Analysis",
            isPresent = true,
            severity = "LOW (Anshik Manglik)",
            explanation = "Mars in 7th House creates minor Manglik alignment. Jupiter aspect neutralizes 75% effect.",
            remedy = "Perform Kumbh Vivah or chant Hanuman Chalisa 7 times on Tuesdays."
        ),
        DoshaAnalysis(
            doshaName = "Kalsarp Yog Check",
            isPresent = false,
            severity = "NONE",
            explanation = "All planets are not trapped between Rahu & Ketu. Your chart is free from Kalsarp Dosha.",
            remedy = "No remedy required. Offer milk on Shivling on Mondays for extra peace."
        ),
        DoshaAnalysis(
            doshaName = "Shani Sade Sati / Dhaiya Status",
            isPresent = true,
            severity = "MODERATE (2nd Dhaiya)",
            explanation = "Saturn transit over natal moon brings workload. Patience and discipline bring career stability.",
            remedy = "Offer mustard oil lamp under Shami tree on Saturdays."
        )
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(doshaList) { dosha ->
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = dosha.doshaName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (dosha.isPresent) CosmicRedAccent else CelestialEmerald
                        )

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (dosha.isPresent) CosmicRedAccent.copy(alpha = 0.2f) else CelestialEmerald.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = dosha.severity,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (dosha.isPresent) CosmicRedAccent else CelestialEmerald,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = dosha.explanation,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.9f)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "✨ Siddha Upay (Remedy):",
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary,
                        style = MaterialTheme.typography.bodySmall
                    )

                    Text(
                        text = dosha.remedy,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun GunMilanTab() {
    val context = LocalContext.current

    // Form States for Ladka & Ladki
    var boyName by remember { mutableStateOf("") }
    var boyDob by remember { mutableStateOf("") }
    var boyTime by remember { mutableStateOf("") }
    var boyCity by remember { mutableStateOf("") }

    var girlName by remember { mutableStateOf("") }
    var girlDob by remember { mutableStateOf("") }
    var girlTime by remember { mutableStateOf("") }
    var girlCity by remember { mutableStateOf("") }

    var isMatchingDone by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Form Title Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "💍 Vivah Kundali Gun Milan (Matching)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MysticGoldPrimary
                )
                Text(
                    text = "Ladka aur Ladki ke details dalkar 36 Ashtakoot Guna, Manglik v Dosha Milan karein",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.85f)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Ladka Details Section
                Text(
                    text = "👦 1. Ladka Details (Boy Information)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MysticGoldPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = boyName,
                    onValueChange = { boyName = it },
                    label = { Text("Ladka Ka Naam (Boy Name)") },
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    OutlinedTextField(
                        value = boyDob,
                        onValueChange = { boyDob = it },
                        label = { Text("DOB (DD/MM/YYYY)") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = boyTime,
                        onValueChange = { boyTime = it },
                        label = { Text("Time (10:30 AM)") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = boyCity,
                    onValueChange = { boyCity = it },
                    label = { Text("Janm City (Birth Place)") },
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Ladki Details Section
                Text(
                    text = "👧 2. Ladki Details (Girl Information)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MysticGoldPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = girlName,
                    onValueChange = { girlName = it },
                    label = { Text("Ladki Ka Naam (Girl Name)") },
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    OutlinedTextField(
                        value = girlDob,
                        onValueChange = { girlDob = it },
                        label = { Text("DOB (DD/MM/YYYY)") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = girlTime,
                        onValueChange = { girlTime = it },
                        label = { Text("Time (02:15 PM)") },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = girlCity,
                    onValueChange = { girlCity = it },
                    label = { Text("Janm City (Birth Place)") },
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        isMatchingDone = true
                        Toast.makeText(context, "Ashtakoot Gun Milan complete ho gaya!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MysticGoldPrimary),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Favorite, contentDescription = "Match", tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Gun Milan & Kundali Matching Karein",
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        if (isMatchingDone) {
            val bName = boyName.ifBlank { "Ladka" }
            val gName = girlName.ifBlank { "Ladki" }

            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, CelestialEmerald),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "✨ 29 / 36 Guna Match (Ati Shubh)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = CelestialEmerald
                            )
                            Text(
                                text = "Kundali Matching: $bName ❤️ $gName",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CelestialEmerald.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "High Compatibility",
                                style = MaterialTheme.typography.labelSmall,
                                color = CelestialEmerald,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 8 Guna Breakdown List
                    val gunaItems = listOf(
                        "1. Varna (Work Compatibility)" to "1 / 1 Point",
                        "2. Vashya (Control & Dominance)" to "2 / 2 Points",
                        "3. Tara (Destiny & Health)" to "3 / 3 Points",
                        "4. Yoni (Intimacy & Attraction)" to "3.5 / 4 Points",
                        "5. Graha Maitri (Friendship)" to "4 / 5 Points",
                        "6. Gana (Temperament)" to "5 / 6 Points",
                        "7. Bhakoot (Family Growth)" to "5.5 / 7 Points",
                        "8. Nadi (Health & Offspring)" to "5 / 8 Points"
                    )

                    gunaItems.forEach { (title, score) ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                        ) {
                            Text(text = title, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.9f))
                            Text(text = score, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MysticGoldPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Manglik & Dosha Status
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "🛡️ Manglik & Dosha Analysis:",
                                fontWeight = FontWeight.Bold,
                                color = MysticGoldPrimary,
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "• $bName: Non-Manglik",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                            Text(
                                text = "• $gName: Anshik Manglik (Neutralized by Jupiter placement)",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                            Text(
                                text = "• Nadi Dosha: No Nadi Dosha found (Both belong to different Nadis)",
                                style = MaterialTheme.typography.bodySmall,
                                color = CelestialEmerald,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Export Buttons for Matching Report
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Save JPG
                        Button(
                            onClick = {
                                val lines = listOf(
                                    "Shadi Kundali Matching Report",
                                    "Boy: $bName (DOB: ${boyDob.ifBlank { "15/08/1998" }})",
                                    "Girl: $gName (DOB: ${girlDob.ifBlank { "20/11/1999" }})",
                                    "--------------------------------------------------",
                                    "Total Guna Match: 29 / 36 Guna (Ati Shubh)",
                                    "Compatibility Rating: Highly Auspicious Match",
                                    "Manglik Status: Anshik Manglik Neutralized",
                                    "Nadi Dosha: NONE (Safe for marriage)"
                                )
                                StorageExporter.saveJpgToGallery(context, "Kundali Matching", lines, "Kundali_Matching")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MysticGoldPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Download, contentDescription = "Save JPG", tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Save JPG", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        // Save PDF
                        Button(
                            onClick = {
                                val content = listOf(
                                    "==================================================",
                                    "Official Marriage Kundali Matching Report",
                                    "==================================================",
                                    "Boy Details:",
                                    "  Name: $bName | DOB: ${boyDob.ifBlank { "15/08/1998" }} | Place: ${boyCity.ifBlank { "Delhi" }}",
                                    "",
                                    "Girl Details:",
                                    "  Name: $gName | DOB: ${girlDob.ifBlank { "20/11/1999" }} | Place: ${girlCity.ifBlank { "Mumbai" }}",
                                    "==================================================",
                                    "Ashtakoot Guna Score: 29 / 36 Guna Match",
                                    "Match Status: Highly Auspicious Marriage Alignment",
                                    "",
                                    "Detailed Breakdown:",
                                    "• Varna: 1/1 | Vashya: 2/2 | Tara: 3/3",
                                    "• Yoni: 3.5/4 | Graha Maitri: 4/5 | Gana: 5/6",
                                    "• Bhakoot: 5.5/7 | Nadi: 5/8",
                                    "",
                                    "Dosha Analysis:",
                                    "• Manglik Match: Neutralized",
                                    "• Nadi Dosha: Absent",
                                    "• Bhakoot Dosha: Absent",
                                    "",
                                    "Recommendation: Auspicious match for marriage."
                                )
                                StorageExporter.savePdfToStorage(context, "Vivah Kundali Matching PDF", content, "Kundali_Matching_PDF")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = "Save PDF", tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Save PDF", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
