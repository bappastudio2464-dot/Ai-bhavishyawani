package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Language
import com.example.ui.components.CosmicBackground
import com.example.ui.components.LanguageSelectorDialog
import com.example.ui.theme.MysticGoldPrimary
import com.example.ui.viewmodel.AstrologyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(viewModel: AstrologyViewModel) {
    val context = LocalContext.current
    val selectedLang by viewModel.selectedLanguage.collectAsState()

    var showLangDialog by remember { mutableStateOf(false) }

    var nameText by remember { mutableStateOf("") }
    var dayText by remember { mutableStateOf("") }
    var monthText by remember { mutableStateOf("") }
    var yearText by remember { mutableStateOf("") }
    var hourText by remember { mutableStateOf("") }
    var minuteText by remember { mutableStateOf("") }
    var amPmText by remember { mutableStateOf("AM") }
    var cityText by remember { mutableStateOf("") }
    var genderText by remember { mutableStateOf("Male") }

    CosmicBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            // Language Selector Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.clickable { showLangDialog = true }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(text = selectedLang.flagEmoji, fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = selectedLang.nativeName,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "Language",
                            tint = MysticGoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // App Logo Banner & Title
            Card(
                shape = CircleShape,
                colors = CardDefaults.cardColors(containerColor = MysticGoldPrimary.copy(alpha = 0.2f)),
                modifier = Modifier.size(88.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_app_icon_1785914251615),
                        contentDescription = "Ai Bhavishyawani Logo",
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Ai Bhavishyawani",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MysticGoldPrimary,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Apni Kundali, Shadi kab hogi & Daily Horoscope janne ke liye Birth Details darj karein",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 6.dp, bottom = 24.dp)
            )

            // Birth Details Form Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {

                    Text(
                        text = "1. Personal Information",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = nameText,
                        onValueChange = { nameText = it },
                        label = { Text("Pura Naam (Full Name)") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        shape = RoundedCornerShape(16.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(
                            selected = genderText == "Male",
                            onClick = { genderText = "Male" },
                            label = { Text("Male (Purush)") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = genderText == "Female",
                            onClick = { genderText = "Female" },
                            label = { Text("Female (Mahila)") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "2. Date of Birth (Janm Tithi)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = dayText,
                            onValueChange = { dayText = it },
                            label = { Text("Day (1-31)") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = monthText,
                            onValueChange = { monthText = it },
                            label = { Text("Month (1-12)") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = yearText,
                            onValueChange = { yearText = it },
                            label = { Text("Year (1998)") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1.2f)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "3. Time of Birth (Janm Samay)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = hourText,
                            onValueChange = { hourText = it },
                            label = { Text("Hour (10)") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = minuteText,
                            onValueChange = { minuteText = it },
                            label = { Text("Min (30)") },
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Row(modifier = Modifier.weight(1.2f)) {
                            FilterChip(
                                selected = amPmText == "AM",
                                onClick = { amPmText = "AM" },
                                label = { Text("AM") }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            FilterChip(
                                selected = amPmText == "PM",
                                onClick = { amPmText = "PM" },
                                label = { Text("PM") }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "4. Place of Birth (Janm Sthan)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MysticGoldPrimary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = cityText,
                        onValueChange = { cityText = it },
                        label = { Text("City, State, Country") },
                        leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                        shape = RoundedCornerShape(16.dp),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Submit Button
            Button(
                onClick = {
                    val nameTrimmed = nameText.trim()
                    val cityTrimmed = cityText.trim()
                    val d = dayText.trim().toIntOrNull()
                    val m = monthText.trim().toIntOrNull()
                    val y = yearText.trim().toIntOrNull()
                    val h = hourText.trim().toIntOrNull()
                    val min = minuteText.trim().toIntOrNull()

                    if (nameTrimmed.isEmpty()) {
                        Toast.makeText(context, "Kripya apna Pura Naam (Full Name) darj karein!", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    if (d == null || d !in 1..31 || m == null || m !in 1..12 || y == null || y !in 1900..2026) {
                        Toast.makeText(context, "Kripya Sahi Janm Tithi (Day 1-31, Month 1-12, Year 1900-2026) darj karein!", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    if (h == null || h !in 1..12 || min == null || min !in 0..59) {
                        Toast.makeText(context, "Kripya Sahi Janm Samay (Hour 1-12, Minute 0-59) darj karein!", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    if (cityTrimmed.isEmpty()) {
                        Toast.makeText(context, "Kripya apna Janm Sthan (City, State, Country) darj karein!", Toast.LENGTH_LONG).show()
                        return@Button
                    }

                    viewModel.saveProfile(
                        name = nameTrimmed,
                        day = d,
                        month = m,
                        year = y,
                        hour = h,
                        minute = min,
                        amPm = amPmText,
                        city = cityTrimmed,
                        gender = genderText
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = MysticGoldPrimary),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Generate Kundali",
                        tint = Color.Black
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Generate Kundali & Dashboard",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showLangDialog) {
        LanguageSelectorDialog(
            currentLanguage = selectedLang,
            onLanguageSelected = { viewModel.setLanguage(it) },
            onDismissRequest = { showLangDialog = false }
        )
    }
}
