package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MembershipTier(val title: String, val badgeColorHex: String, val discountPercent: Int) {
    FREE("Basic Member", "#9E9E9E", 0),
    GOLD("Gold Astro Member", "#FFD700", 15),
    DIAMOND("Diamond VIP", "#00E5FF", 30),
    CORPORATE_MEMBER("Corporate Exclusive", "#E040FB", 40)
}

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val name: String = "",
    val dobDay: Int = 1,
    val dobMonth: Int = 1,
    val dobYear: Int = 1998,
    val birthHour: Int = 10,
    val birthMinute: Int = 30,
    val birthAmPm: String = "AM",
    val birthCity: String = "New Delhi",
    val birthCountry: String = "India",
    val gender: String = "Male",
    val rashi: String = "Aries (Mesh)",
    val sunSign: String = "Aries",
    val lagna: String = "Taurus Ascendant",
    val nakshatra: String = "Ashwini",
    val walletBalance: Double = 500.0,
    val membershipTier: String = MembershipTier.GOLD.name,
    val selectedLanguage: String = Language.HINDI.name,
    val isDarkTheme: Boolean = true,
    val isOnboarded: Boolean = false,
    val latitude: String = "28.6139",
    val longitude: String = "77.2090",
    val isVedAstroCalculated: Boolean = true,
    val aiHoroscopeSummary: String = "",
    val aiHoroscopeMantra: String = ""
)
