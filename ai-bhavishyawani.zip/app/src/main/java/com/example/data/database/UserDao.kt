package com.example.data.database

import androidx.room.*
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM user_profile WHERE id = 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProfile(profile: UserProfile)

    @Query("UPDATE user_profile SET walletBalance = :newBalance WHERE id = 1")
    suspend fun updateWalletBalance(newBalance: Double)

    @Query("UPDATE user_profile SET membershipTier = :tier WHERE id = 1")
    suspend fun updateMembershipTier(tier: String)

    @Query("UPDATE user_profile SET selectedLanguage = :langCode WHERE id = 1")
    suspend fun updateLanguage(langCode: String)

    @Query("UPDATE user_profile SET isDarkTheme = :isDark WHERE id = 1")
    suspend fun updateDarkTheme(isDark: Boolean)
}
