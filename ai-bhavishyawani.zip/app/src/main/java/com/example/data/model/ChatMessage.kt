package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sender: String, // "USER", "AI_ASTROLOGER", "HUMAN_EXPERT"
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val languageCode: String = "hi",
    val topic: String = "GENERAL" // "SHADI", "CAREER", "KUNDALI", "GENERAL"
)
