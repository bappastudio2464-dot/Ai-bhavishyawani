package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transit_alerts")
data class TransitAlert(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val planetName: String, // "Jupiter", "Saturn", "Rahu", "Venus"
    val transitType: String, // "Mahadasha", "Gochara", "Transit"
    val impactLevel: String, // "HIGH_POSITIVE", "MODERATE", "CAUTION"
    val dateString: String,
    val remedyAdvice: String,
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
