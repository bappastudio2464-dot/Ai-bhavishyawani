package com.example.data.database

import androidx.room.*
import com.example.data.model.TransitAlert
import kotlinx.coroutines.flow.Flow

@Dao
interface TransitAlertDao {
    @Query("SELECT * FROM transit_alerts ORDER BY timestamp DESC")
    fun getAllAlerts(): Flow<List<TransitAlert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<TransitAlert>)

    @Query("UPDATE transit_alerts SET isRead = 1 WHERE id = :alertId")
    suspend fun markAsRead(alertId: Int)
}
