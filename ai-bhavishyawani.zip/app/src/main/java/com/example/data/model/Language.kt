package com.example.data.model

enum class Language(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val flagEmoji: String
) {
    HINDI("hi", "Hindi", "हिंदी", "🇮🇳"),
    ENGLISH("en", "English", "English", "🇬🇧"),
    HINGLISH("hi-en", "Hinglish", "Hinglish", "🇮🇳"),
    MARATHI("mr", "Marathi", "मराठी", "🇮🇳"),
    GUJARATI("gu", "Gujarati", "ગુજરાતી", "🇮🇳"),
    BENGALI("bn", "Bengali", "বাংলা", "🇮🇳"),
    TAMIL("ta", "Tamil", "தமிழ்", "🇮🇳"),
    TELUGU("te", "Telugu", "తెలుగు", "🇮🇳"),
    PUNJABI("pa", "Punjabi", "ਪੰਜਾਬੀ", "🇮🇳"),
    KANNADA("kn", "Kannada", "ಕನ್ನಡ", "🇮🇳")
}
