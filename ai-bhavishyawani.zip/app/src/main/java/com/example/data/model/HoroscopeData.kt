package com.example.data.model

data class DailyHoroscope(
    val rashiName: String,
    val moodSelected: String,
    val overallScore: Int, // 1 to 100
    val loveScore: Int,
    val careerScore: Int,
    val healthScore: Int,
    val wealthScore: Int,
    val summaryText: String,
    val moodGuidance: String,
    val luckyColor: String,
    val luckyNumber: Int,
    val luckyTime: String,
    val remedyOfDay: String,
    val mantraOfDay: String,
    val overviewText: String = "Aaj Grah Gochar anukul sthan me hone se aapke saare bante kaam safal honge. Vyapar aur career me naye dwar khulenge.",
    val hurdlesText: String = "Aaj dopehar me achanak daud-dhoop ya choti behas se bachein. Apne gusse par kabu rakhein.",
    val remedyText: String = "Subah Surya Dev ko Tambe ke patra se jal arpit karein aur Om Ghrini Suryaya Namah ka 11 baar jaap karein."
)

data class KundaliDetail(
    val rashi: String,
    val sunSign: String,
    val lagnaAscendant: String,
    val nakshatra: String,
    val nakshatraPada: Int,
    val planetPositions: List<PlanetPosition>,
    val houses: List<HouseDetail>,
    val doshas: List<DoshaAnalysis>,
    val dashaPeriod: String
)

data class PlanetPosition(
    val planetName: String,
    val houseNumber: Int,
    val rashi: String,
    val isRetrograde: Boolean
)

data class HouseDetail(
    val houseNumber: Int,
    val lordPlanet: String,
    val significance: String
)

data class DoshaAnalysis(
    val doshaName: String, // e.g. "Manglik Dosha", "Kalsarp Yog", "Sade Sati"
    val isPresent: Boolean,
    val severity: String, // "LOW", "MEDIUM", "HIGH", "NONE"
    val explanation: String,
    val remedy: String
)

data class MarriagePrediction(
    val estimatedMarriageAge: String,
    val probableYearRange: String,
    val lifePartnerCharacteristics: String,
    val partnerDirection: String,
    val gunaMilanScore: Int, // out of 36
    val compatibilityRating: String,
    val delayedMarriageCauses: String,
    val powerfulMarriageRemedies: List<String>
)
