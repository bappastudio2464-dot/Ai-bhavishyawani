package com.example.data.remote

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.util.Locale
import java.util.concurrent.TimeUnit

data class VedAstroResponse(
    val Status: String? = null,
    val Payload: String? = null
)

interface VedAstroApiService {
    @GET("Calculate/PlanetSignName/PlanetName/Moon/Location/{lat},{lng}/Time/{timeStr}/Ayanamsa/LAHIRI")
    suspend fun getMoonSign(
        @Path("lat") lat: String,
        @Path("lng") lng: String,
        @Path(value = "timeStr", encoded = true) timeStr: String
    ): VedAstroResponse
}

object VedAstroClient {
    private const val BASE_URL = "https://api.vedastro.org/api/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    val service: VedAstroApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(VedAstroApiService::class.java)
    }

    /**
     * Converts birth parameters into VedAstro Time String Format:
     * "HH:MM DD/MM/YYYY ±HH:MM" (e.g., "08:45 03/08/1993 +05:30")
     */
    fun formatVedAstroTime(
        day: Int,
        month: Int,
        year: Int,
        hour: Int,
        minute: Int,
        amPm: String,
        timezoneOffset: String = "+05:30"
    ): String {
        var h24 = hour % 12
        if (amPm.equals("PM", ignoreCase = true)) {
            h24 += 12
        } else if (amPm.equals("AM", ignoreCase = true) && hour == 12) {
            h24 = 0
        }
        val formattedHourMin = String.format(Locale.US, "%02d:%02d", h24, minute)
        val formattedDate = String.format(Locale.US, "%02d/%02d/%04d", day, month, year)
        return "$formattedHourMin $formattedDate $timezoneOffset"
    }

    /**
     * Resolves Latitude and Longitude coordinates for Indian and major global cities.
     */
    fun getCityCoordinates(cityName: String): Pair<String, String> {
        val cityClean = cityName.trim().lowercase()
        return when {
            cityClean.contains("kanpur") -> Pair("26.4499", "80.3319")
            cityClean.contains("delhi") -> Pair("28.6139", "77.2090")
            cityClean.contains("mumbai") -> Pair("19.0760", "72.8777")
            cityClean.contains("lucknow") -> Pair("26.8467", "80.9462")
            cityClean.contains("kolkata") || cityClean.contains("calcutta") -> Pair("22.5726", "88.3639")
            cityClean.contains("jaipur") -> Pair("26.9124", "75.7873")
            cityClean.contains("bengaluru") || cityClean.contains("bangalore") -> Pair("12.9716", "77.5946")
            cityClean.contains("patna") -> Pair("25.5941", "85.1376")
            cityClean.contains("varanasi") || cityClean.contains("banaras") || cityClean.contains("kashi") -> Pair("25.3176", "82.9739")
            cityClean.contains("ahmedabad") -> Pair("23.0225", "72.5714")
            cityClean.contains("pune") -> Pair("18.5204", "73.8567")
            cityClean.contains("hyderabad") -> Pair("17.3850", "78.4867")
            cityClean.contains("chennai") || cityClean.contains("madras") -> Pair("13.0827", "80.2707")
            cityClean.contains("chandigarh") -> Pair("30.7333", "76.7794")
            cityClean.contains("indore") -> Pair("22.7196", "75.8577")
            cityClean.contains("bhopal") -> Pair("23.2599", "77.4126")
            cityClean.contains("agra") -> Pair("27.1767", "78.0081")
            cityClean.contains("prayagraj") || cityClean.contains("allahabad") -> Pair("25.4358", "81.8463")
            else -> Pair("28.6139", "77.2090") // Default to New Delhi
        }
    }

    /**
     * Map raw sign string from VedAstro / Lahiri to standard English + Vedic Rashi name.
     */
    fun mapSignToRashi(rawSign: String?): String {
        if (rawSign.isNullOrBlank()) return "Aries (Mesh)"
        val signLower = rawSign.lowercase(Locale.US)
        return when {
            signLower.contains("aries") || signLower.contains("mesh") -> "Aries (Mesh)"
            signLower.contains("taurus") || signLower.contains("vrish") || signLower.contains("vrishabh") -> "Taurus (Vrishabh)"
            signLower.contains("gemini") || signLower.contains("mithun") -> "Gemini (Mithun)"
            signLower.contains("cancer") || signLower.contains("kark") -> "Cancer (Kark)"
            signLower.contains("leo") || signLower.contains("singh") || signLower.contains("simha") -> "Leo (Singh)"
            signLower.contains("virgo") || signLower.contains("kanya") -> "Virgo (Kanya)"
            signLower.contains("libra") || signLower.contains("tula") -> "Libra (Tula)"
            signLower.contains("scorpio") || signLower.contains("vrishchik") -> "Scorpio (Vrishchik)"
            signLower.contains("sagittarius") || signLower.contains("dhanu") -> "Sagittarius (Dhanu)"
            signLower.contains("capricorn") || signLower.contains("makar") || signLower.contains("makara") -> "Capricorn (Makar)"
            signLower.contains("aquarius") || signLower.contains("kumbh") || signLower.contains("kumbha") -> "Aquarius (Kumbh)"
            signLower.contains("pisces") || signLower.contains("meen") || signLower.contains("meena") -> "Pisces (Meen)"
            else -> "Aries (Mesh)"
        }
    }

    private fun String?.isNull_or_blank(): Boolean = this == null || this.trim().isEmpty()
}
